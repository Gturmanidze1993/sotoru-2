import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../l10n/strings.dart';
import '../../models/venue.dart';
import '../../providers/providers.dart';
import '../../providers/settings_provider.dart';
import '../../services/remote_config.dart';
import '../../services/analytics.dart';
import '../venue/venue_detail_sheet.dart';
import '../sponsor/sponsor_card.dart';

class SwipeScreen extends ConsumerWidget {
  const SwipeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppStrings.of(context);
    final deck = ref.watch(deckProvider);
    final rcAsync = ref.watch(remoteConfigProvider);
    final query = ref.watch(searchQueryProvider);
    final chips = ref.watch(quickChipsProvider);
    final filtered = deck.where((v) {
      final q = query.toLowerCase();
      final qok = q.isEmpty || v.name.toLowerCase().contains(q) || v.district.toLowerCase().contains(q);
      bool chok = true;
      if (chips.contains('open_now') && !v.openNow) chok = false;
      if (chips.contains('terrace') && !v.tags.contains('terrace')) chok = false;
      if (chips.contains('quiet') && v.noise > 2) chok = false;
      if (chips.contains('live_music') && !v.tags.contains('live_music')) chok = false;
      if (chips.contains('hookah') && !v.tags.contains('hookah')) chok = false;
      if (chips.contains('late_kitchen') && !v.tags.contains('late_kitchen')) chok = false;
      return qok && chok;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tonight'),
        actions: [IconButton(onPressed: () => ref.read(deckProvider.notifier).refresh(), icon: const Icon(Icons.refresh))],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(92),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Column(children: [
              TextField(onChanged: (s) => ref.read(searchQueryProvider.notifier).state = s, decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: t.t('search'))),
              const SizedBox(height: 8),
              _ChipsRow(),
            ]),
          ),
        ),
      ),
      body: rcAsync.when(
        data: (rc) {
          final list = filtered;
          if (list.isEmpty) return Center(child: Text(t.t('no_results')));
          final withSponsors = _mixSponsors(list, rc);
          return Stack(children: List.generate(min(withSponsors.length, 3), (i) {
            final item = withSponsors[i];
            if (item is Venue) return _SwipeCard(v: item, i: i);
            return _StaticSponsorCard(i: i);
          }));
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, __) => const Center(child: Text('Config error')),
      ),
    );
  }

  List<Object> _mixSponsors(List<Venue> list, RemoteConfig rc) {
    final freq = rc.sponsorFrequency();
    final out = <Object>[]; int shown = 0;
    for (var i = 0; i < list.length; i++) {
      if (rc.flag('sponsor_enabled') && i >= 2 && i % freq == 0 && shown < rc.sponsorDailyCap()) { out.add('sponsor'); shown++; }
      out.add(list[i]);
    }
    return out;
  }
}

class _ChipsRow extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppStrings.of(context);
    final options = const [
      ('open_now','open_now'),
      ('terrace','terrace'),
      ('quiet','quiet'),
      ('live_music','live_music'),
      ('hookah','hookah'),
      ('late_kitchen','late_kitchen'),
    ];
    final sel = ref.watch(quickChipsProvider);
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: options.map((pair) {
        final key = pair.$1; final labelKey = pair.$2; final selected = sel.contains(key);
        return Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: ChoiceChip(label: Text(t.t(labelKey)), selected: selected, onSelected: (_) {
            final set = {...sel}; if (selected) { set.remove(key); } else { set.add(key); }
            ref.read(quickChipsProvider.notifier).state = set;
          }),
        );
      }).toList()),
    );
  }
}

class _StaticSponsorCard extends StatelessWidget {
  final int i; const _StaticSponsorCard({required this.i});
  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      top: 12.0 * i, left: 12.0 * i, right: 12.0 * i, bottom: 12.0 * i,
      child: const SponsorCard(title: 'Tonight in Tbilisi', imageUrl: 'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=1200'),
    );
  }
}

class _DraggableVenueCard extends ConsumerStatefulWidget {
  final Venue v; final int i;
  const _DraggableVenueCard({required this.v, required this.i});
  @override
  ConsumerState<_DraggableVenueCard> createState() => _DraggableVenueCardState();
}

class _DraggableVenueCardState extends ConsumerState<_DraggableVenueCard> {
  @override
  Widget build(BuildContext context) {
    final v = widget.v;
    final width = MediaQuery.of(context).size.width;
    final threshold = width * 0.25;
    final haptics = ref.watch(settingsProvider.select((s) => s.hapticsEnabled));
    return Positioned.fill(
      top: 12.0 * widget.i, left: 12.0 * widget.i, right: 12.0 * widget.i, bottom: 12.0 * widget.i,
      child: GestureDetector(
        onLongPress: () => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => VenueDetailSheet(venue: v)),
        child: Draggable(
          feedback: _card(v), childWhenDragging: const SizedBox.shrink(),
          onDragEnd: (d) {
            final dx = d.offset.dx;
            if (dx > threshold) {
              ref.read(shortlistProvider.notifier).add(v);
              ref.read(deckProvider.notifier).swipeLeft(v);
              if (haptics) HapticFeedback.lightImpact();
              Analytics.log('swipe_right', {'venueId': v.id});
            } else if (dx < -threshold) {
              ref.read(deckProvider.notifier).swipeLeft(v);
              Analytics.log('swipe_left', {'venueId': v.id});
            } else {
              ref.read(deckProvider.notifier).markViewed(v);
            }
          },
          child: _card(v),
        ),
      ),
    );
  }

  Widget _badge(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    margin: const EdgeInsets.only(right: 6, bottom: 6),
    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
    child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 12)),
  );

  Widget _card(Venue v) {
    return Container(
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        image: DecorationImage(image: NetworkImage(v.photoUrl), fit: BoxFit.cover),
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black54, Colors.transparent]),
        ),
        padding: const EdgeInsets.all(16), alignment: Alignment.bottomLeft,
        child: Column(mainAxisAlignment: MainAxisAlignment.end, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${v.name} • ${v.type} • ${v.rating.toStringAsFixed(1)}★', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(children: [
            _badge(v.district),
            _badge('GEL ${v.priceBand}'),
            _badge('Queue ${v.queueMinutes}m'),
            _badge('Noise ${v.noise}/5'),
            if (v.openNow) _badge('Open'),
          ]),
        ]),
      ),
    );
  }
}
