import 'dart:io';
import 'package:flutter/material.dart';

class ViewerImageScreen extends StatelessWidget {
  final String path;
  const ViewerImageScreen({super.key, required this.path});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, iconTheme: const IconThemeData(color: Colors.white)),
      body: Center(child: InteractiveViewer(child: Image.file(File(path), fit: BoxFit.contain))),
    );
  }
}
