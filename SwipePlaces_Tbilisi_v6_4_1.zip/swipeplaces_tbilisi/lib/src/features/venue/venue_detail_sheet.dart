import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../l10n/strings.dart';
import '../../models/venue.dart';
import '../../models/media_item.dart';
import '../../providers/providers.dart';
import '../../services/media_repository.dart';
import '../../ui/toast.dart';
import 'video_player_screen.dart';
import 'viewer_image_screen.dart';

class VenueDetailSheet extends ConsumerWidget {
  final Venue venue;
  const VenueDetailSheet({super.key, required this.venue});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppStrings.of(context);
    final media = ref.watch(mediaProvider(venue.id));
    final now = DateTime.now();
    final lateNight = now.hour >= 23 || now.hour < 5;
    return DraggableScrollableSheet(
      initialChildSize: 0.55, maxChildSize: 0.95, minChildSize: 0.3, snap: true, snapSizes: const [0.5, 0.9], expand: false,
      builder: (context, controller) {
        return Material(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)), clipBehavior: Clip.antiAlias,
          child: Column(children: [
            Container(width: 40, height: 4, margin: const EdgeInsets.only(top: 8), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(2))),
            Expanded(child: ListView(controller: controller, children: [
              Semantics(label: 'Venue cover image', child: AspectRatio(aspectRatio: 16/9, child: Image.network(venue.photoUrl, fit: BoxFit.cover))),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(venue.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('${venue.type} • ${venue.rating.toStringAsFixed(1)}★'),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    Chip(label: Text(venue.district)),
                    Chip(label: Text('GEL ${venue.priceBand}')),
                    Chip(label: Text('Queue ${venue.queueMinutes}m')),
                    Chip(label: Text('Noise ${venue.noise}/5')),
                    if (venue.openNow) const Chip(label: Text('Open')),
                  ]),
                  const SizedBox(height: 12),
                  Row(children: [
                    if (venue.phone.isNotEmpty) Expanded(child: ElevatedButton.icon(onPressed: () { final uri = Uri.parse('tel:${venue.phone}'); launchUrl(uri); }, icon: const Icon(Icons.call), label: const Text('Call'))),
                    if (venue.phone.isNotEmpty) const SizedBox(width: 12),
                    Expanded(child: ElevatedButton.icon(onPressed: () { final query = Uri.encodeComponent(venue.name); final hasId = venue.id.isNotEmpty; final uri = Uri.parse(hasId ? 'https://www.google.com/maps/search/?api=1&query=$query&query_place_id=${venue.id}' : 'https://www.google.com/maps/search/?api=1&query=$query'); launchUrl(uri, mode: LaunchMode.externalApplication); }, icon: const Icon(Icons.directions), label: const Text('Directions'))),
                  ]),
                  if (lateNight) ...[
                    const SizedBox(height: 8),
                    Row(children: [
                      Expanded(child: OutlinedButton.icon(onPressed: () { final uri = Uri.parse('bolt://ride?pickup=my_location&destination_lat=${venue.lat}&destination_lon=${venue.lng}'); launchUrl(uri, mode: LaunchMode.externalApplication); }, icon: const Icon(Icons.local_taxi), label: const Text('Bolt'))),
                      const SizedBox(width: 12),
                      Expanded(child: OutlinedButton.icon(onPressed: () { final uri = Uri.parse('yandexnavi://build_route_on_map?lat_to=${venue.lat}&lon_to=${venue.lng}'); launchUrl(uri, mode: LaunchMode.externalApplication); }, icon: const Icon(Icons.local_taxi), label: const Text('Yandex Go'))),
                    ]),
                  ],
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: () => ref.read(shortlistProvider.notifier).add(venue), icon: const Icon(Icons.favorite_border), label: const Text('Shortlist'))),
                    const SizedBox(width: 12),
                    Expanded(child: OutlinedButton.icon(onPressed: () => ref.read(savedProvider.notifier).add(venue), icon: const Icon(Icons.bookmark_border), label: const Text('Save'))),
                  ]),
                  const SizedBox(height: 16),
                  Text(t.t('photos_videos'), style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  _MediaGrid(venueId: venue.id, items: media),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: () => _pickImage(context, ref, venue.id), icon: const Icon(Icons.photo), label: Text(t.t('add_photo')))),
                    const SizedBox(width: 12),
                    Expanded(child: OutlinedButton.icon(onPressed: () => _pickVideo(context, ref, venue.id), icon: const Icon(Icons.videocam), label: Text(t.t('add_video')))),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: TextButton.icon(onPressed: () => _pronounce(context), icon: const Icon(Icons.record_voice_over), label: Text(t.t('pronounce')))),
                    const SizedBox(width: 12),
                    Expanded(child: TextButton.icon(onPressed: () => _translate(context), icon: const Icon(Icons.translate), label: Text(t.t('translate_menu')))),
                  ]),
                ]),
              ),
            ])),
          ]),
        );
      },
    );
  }

  Future<void> _pickImage(BuildContext context, WidgetRef ref, String venueId) async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 95);
    if (file == null) return;
    final repo = ref.read(mediaRepoProvider);
    final item = await repo.saveImage(venueId, file);
    await ref.read(mediaProvider(venueId).notifier).add(item);
    Toasts.show(context, 'Photo added');
  }

  Future<void> _pickVideo(BuildContext context, WidgetRef ref, String venueId) async {
    final picker = ImagePicker();
    final file = await picker.pickVideo(source: ImageSource.camera, maxDuration: const Duration(seconds: 10));
    if (file == null) return;
    final repo = ref.read(mediaRepoProvider);
    final item = await repo.saveVideo(venueId, file, maxDurationSeconds: 10);
    await ref.read(mediaProvider(venueId).notifier).add(item);
    Toasts.show(context, 'Video added');
  }

  void _pronounce(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Pronounce'), content: const Text('Pronunciation guide will appear here.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],));
  }
  void _translate(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Translate menu'), content: const Text('Menu translation will appear here.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],));
  }
}

class _MediaGrid extends ConsumerWidget {
  final String venueId; final List<MediaItem> items;
  const _MediaGrid({required this.venueId, required this.items});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (items.isEmpty) return const Text('No media yet');
    final count = items.length < 12 ? items.length : 12;
    return GridView.builder(
      shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 4, mainAxisSpacing: 4),
      itemCount: count,
      itemBuilder: (context, i) {
        final m = items[i];
        if (m.type == 'image') {
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ViewerImageScreen(path: m.path))),
            onLongPress: () => _showMediaActions(context, ref, m),
            child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(m.path), fit: BoxFit.cover, semanticLabel: 'User photo')),
          );
        } else {
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPlayerScreen(path: m.path))),
            onLongPress: () => _showMediaActions(context, ref, m),
            child: Stack(fit: StackFit.expand, children: [
              Container(color: Colors.black12),
              const Center(child: Icon(Icons.play_circle_outline, size: 36, color: Colors.white)),
              Positioned(right: 4, bottom: 4, child: Container(color: Colors.black54, padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), child: const Text('10s', style: TextStyle(color: Colors.white, fontSize: 12)))),
            ]),
          );
        }
      },
    );
  }

  void _showMediaActions(BuildContext context, WidgetRef ref, MediaItem m) {
    showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.delete_outline), title: const Text('Delete'), onTap: () async { Navigator.pop(context); await ref.read(mediaProvider(venueId).notifier).delete(m); HapticFeedback.heavyImpact(); Toasts.show(context, 'Deleted'); }),
      ListTile(leading: const Icon(Icons.flag_outlined), title: const Text('Report media'), onTap: () { Navigator.pop(context); _report(context, ref, m); }),
    ])));
  }

  void _report(BuildContext context, WidgetRef ref, MediaItem m) async {
    String? selected;
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Report media'),
      content: StatefulBuilder(builder: (c, set) => Column(mainAxisSize: MainAxisSize.min, children: [
        RadioListTile(value: 'spam', groupValue: selected, onChanged: (v) => set(() => selected = v as String?), title: const Text('Spam')),
        RadioListTile(value: 'offensive', groupValue: selected, onChanged: (v) => set(() => selected = v as String?), title: const Text('Offensive')),
        RadioListTile(value: 'off_topic', groupValue: selected, onChanged: (v) => set(() => selected = v as String?), title: const Text('Off topic')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), TextButton(onPressed: () { Navigator.pop(context, selected); }, child: const Text('Submit'))],
    ));
    if (selected != null) { await ref.read(mediaProvider(venueId).notifier).report(m, selected!); Toasts.show(context, 'Reported'); }
  }
}
