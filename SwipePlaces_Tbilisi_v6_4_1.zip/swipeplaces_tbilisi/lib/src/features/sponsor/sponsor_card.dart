import 'package:flutter/material.dart';
class SponsorCard extends StatelessWidget {
  final String title; final String imageUrl;
  const SponsorCard({super.key, required this.title, required this.imageUrl});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), image: DecorationImage(image: NetworkImage(imageUrl), fit: BoxFit.cover)),
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black54, Colors.transparent])),
        padding: const EdgeInsets.all(16), alignment: Alignment.bottomLeft,
        child: Text('Sponsored • $title', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
