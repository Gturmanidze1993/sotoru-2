import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../../l10n/strings.dart';
import '../../providers/providers.dart';
import '../../models/venue.dart';
import '../venue/venue_detail_sheet.dart';
import '../../ui/toast.dart';

class ShortlistScreen extends ConsumerStatefulWidget {
  const ShortlistScreen({super.key});
  @override
  ConsumerState<ShortlistScreen> createState() => _ShortlistScreenState();
}
class _ShortlistScreenState extends ConsumerState<ShortlistScreen> {
  GoogleMapController? map;
  @override
  Widget build(BuildContext context) {
    final t = AppStrings.of(context);
    final items = ref.watch(shortlistProvider);
    final markers = items.map((v) => Marker(markerId: MarkerId(v.id), position: LatLng(v.lat, v.lng), infoWindow: InfoWindow(title: v.name))).toSet();
    return Scaffold(
      appBar: AppBar(title: const Text('Shortlist'), actions: [
        if (items.isNotEmpty) IconButton(onPressed: () { final text = items.map((v) => '${v.name} • ${v.address}').join('\n'); Share.share(text); }, icon: const Icon(Icons.share)),
      ]),
      body: Column(children: [
        SizedBox(height: 220, child: GoogleMap(onMapCreated: (c) => map = c, initialCameraPosition: CameraPosition(target: items.isNotEmpty ? LatLng(items[0].lat, items[0].lng) : const LatLng(41.7151, 44.8271), zoom: 12), markers: markers, myLocationButtonEnabled: false, zoomControlsEnabled: false)),
        if (items.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 0), child: SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () => _exportCalendar(context, items), icon: const Icon(Icons.event), label: Text(t.t('export_calendar'))))),
        Expanded(child: items.isEmpty ? const Center(child: Text('Swipe right to add places')) : ListView.builder(itemCount: items.length, itemBuilder: (context, i) => _VenueTile(v: items[i]))),
      ]),
    );
  }
  Future<void> _exportCalendar(BuildContext context, List<Venue> items) async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day, 20, 0);
    final end = start.add(const Duration(hours: 4));
    final buf = StringBuffer()..writeln('BEGIN:VCALENDAR')..writeln('VERSION:2.0');
    for (final v in items) {
      buf.writeln('BEGIN:VEVENT');
      buf.writeln('DTSTART:${_fmt(start)}');
      buf.writeln('DTEND:${_fmt(end)}');
      buf.writeln('SUMMARY:${_escape(v.name)}');
      buf.writeln('LOCATION:${_escape(v.address)}');
      buf.writeln('DESCRIPTION:${_escape('Plan from SwipePlaces')}');
      buf.writeln('END:VEVENT');
    }
    buf.writeln('END:VCALENDAR');
    final file = File('${Directory.systemTemp.path}/plan.ics'); await file.writeAsString(buf.toString());
    await Share.shareFiles([file.path], text: 'Tonight plan'); Toasts.show(context, 'Calendar file created');
  }
  String _fmt(DateTime dt) { final utc = dt.toUtc(); String two(int n) => n.toString().padLeft(2, '0'); return '${utc.year}${two(utc.month)}${two(utc.day)}T${two(utc.hour)}${two(utc.minute)}${two(utc.second)}Z'; }
  String _escape(String s) => s.replaceAll(',', '\\,').replaceAll(';', '\\;');
}
class _VenueTile extends StatelessWidget {
  final Venue v; const _VenueTile({required this.v});
  @override
  Widget build(BuildContext context) {
    return ListTile(leading: CircleAvatar(backgroundImage: NetworkImage(v.photoUrl)), title: Text(v.name), subtitle: Text('${v.district} • GEL ${v.priceBand} • ${v.address}'), trailing: const Icon(Icons.chevron_right), onTap: () => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => VenueDetailSheet(venue: v)));
  }
}
