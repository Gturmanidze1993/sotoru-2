import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../../providers/providers.dart';
import '../../models/venue.dart';
import '../venue/venue_detail_sheet.dart';

class MapScreen extends ConsumerStatefulWidget {
  const MapScreen({super.key});
  @override
  ConsumerState<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends ConsumerState<MapScreen> {
  GoogleMapController? map;
  final districts = const ['All','Vake','Vera','Saburtalo','Old Tbilisi','Marjanishvili','Didube'];
  @override
  Widget build(BuildContext context) {
    final deck = ref.watch(deckProvider);
    final sel = ref.watch(districtFilterProvider);
    final filtered = sel == null || sel == 'All' ? deck : deck.where((v) => v.district == sel).toList();
    final markers = filtered.map((v) => Marker(
      markerId: MarkerId(v.id), position: LatLng(v.lat, v.lng),
      infoWindow: InfoWindow(title: v.name, snippet: v.district),
      onTap: () { showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => VenueDetailSheet(venue: v)); },
    )).toSet();
    return Scaffold(
      appBar: AppBar(title: const Text('Map')),
      body: Stack(children: [
        GoogleMap(
          onMapCreated: (c) => map = c,
          initialCameraPosition: CameraPosition(target: filtered.isNotEmpty ? LatLng(filtered[0].lat, filtered[0].lng) : const LatLng(41.7151, 44.8271), zoom: 12),
          markers: markers, myLocationButtonEnabled: false, zoomControlsEnabled: false,
        ),
        Positioned(top: 12, left: 12, right: 12, child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: districts.map((d) {
            final selected = (sel ?? 'All') == d;
            return Padding(padding: const EdgeInsets.only(right: 8.0), child: ChoiceChip(label: Text(d), selected: selected, onSelected: (_) => ref.read(districtFilterProvider.notifier).state = d == 'All' ? null : d));
          }).toList()),
        )),
        Positioned(bottom: 24, left: 24, child: FloatingActionButton.small(onPressed: () { if (filtered.isNotEmpty) { map?.animateCamera(CameraUpdate.newLatLng(LatLng(filtered[0].lat, filtered[0].lng))); } }, child: const Icon(Icons.my_location))),
      ]),
    );
  }
}
