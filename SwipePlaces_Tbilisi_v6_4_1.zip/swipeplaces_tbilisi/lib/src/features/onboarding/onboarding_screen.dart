import 'package:flutter/material.dart';
import '../home/home_shell.dart';
import '../../providers/settings_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class OnboardingScreen extends ConsumerWidget {
  const OnboardingScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              const Text('SwipePlaces Tbilisi', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text('Fast picks for tonight. Bars, restaurants, clubs.'),
              const Spacer(),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () { ref.read(settingsProvider.notifier).setProfile('local'); Navigator.pushReplacementNamed(context, HomeShell.route); }, child: const Text('I live here'))),
                const SizedBox(width: 12),
                Expanded(child: ElevatedButton(onPressed: () { ref.read(settingsProvider.notifier).setProfile('visitor'); Navigator.pushReplacementNamed(context, HomeShell.route); }, child: const Text('I am visiting'))),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
