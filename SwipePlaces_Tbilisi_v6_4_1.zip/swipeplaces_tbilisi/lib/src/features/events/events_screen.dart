import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/providers.dart';
import '../../models/event_item.dart';

class EventsScreen extends ConsumerWidget {
  const EventsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final events = ref.watch(eventsProvider);
    final byDate = <String, List<EventItem>>{};
    for (final e in events) { byDate.putIfAbsent(e.date, () => []).add(e); }
    final dates = byDate.keys.toList()..sort();
    return Scaffold(
      appBar: AppBar(title: const Text('Events')),
      body: ListView.builder(
        itemCount: dates.length,
        itemBuilder: (context, i) {
          final d = dates[i]; final list = byDate[d]!;
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 6), child: Text(d, style: const TextStyle(fontWeight: FontWeight.bold))),
            ...list.map((e) => _EventTile(e: e)),
          ]);
        },
      ),
    );
  }
}
class _EventTile extends StatelessWidget {
  final EventItem e; const _EventTile({required this.e});
  @override
  Widget build(BuildContext context) {
    return ListTile(leading: SizedBox(width: 72, child: Image.network(e.coverUrl, fit: BoxFit.cover)), title: Text(e.title), subtitle: Text('${e.venueName} • ${e.start} - ${e.end}'));
  }
}
