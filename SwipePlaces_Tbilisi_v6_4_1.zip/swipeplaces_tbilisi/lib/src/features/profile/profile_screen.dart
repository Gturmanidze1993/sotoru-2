import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../l10n/strings.dart';
import '../../providers/providers.dart';
import '../../providers/settings_provider.dart';
import '../../models/venue.dart';
import '../venue/venue_detail_sheet.dart';
import '../../ui/toast.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saved = ref.watch(savedProvider);
    final history = ref.watch(historyProvider);
    final profile = ref.watch(settingsProvider.select((s) => s.profile));
    final seen = ref.watch(settingsProvider.select((s) => s.seenPriceLegend));
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(title: const Text('Profile'), bottom: const TabBar(tabs: [Tab(text: 'Saved'), Tab(text: 'History'), Tab(text: 'Settings')])),
        body: TabBarView(children: [ _List(list: saved), _List(list: history), _SettingsSection(current: profile, seen: seen) ]),
      ),
    );
  }
}
class _List extends StatelessWidget {
  final List<Venue> list; const _List({required this.list});
  @override
  Widget build(BuildContext context) {
    if (list.isEmpty) return const Center(child: Text('Empty'));
    return ListView.builder(itemCount: list.length, itemBuilder: (c, i) { final v = list[i]; return ListTile(leading: CircleAvatar(backgroundImage: NetworkImage(v.photoUrl)), title: Text(v.name), subtitle: Text('${v.district} • GEL ${v.priceBand}'), trailing: const Icon(Icons.chevron_right), onTap: () => showModalBottomSheet(context: c, isScrollControlled: true, builder: (_) => VenueDetailSheet(venue: v))); });
  }
}
class _SettingsSection extends ConsumerWidget {
  final String current; final bool seen;
  const _SettingsSection({required this.current, required this.seen});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = AppStrings.of(context);
    final haptics = ref.watch(settingsProvider.select((s) => s.hapticsEnabled));
    return ListView(children: [
      ListTile(leading: const Icon(Icons.person_pin_circle), title: const Text('Profile type'), subtitle: Text(current == 'local' ? 'Local' : 'Visitor'), onTap: () { final next = current == 'local' ? 'visitor' : 'local'; ref.read(settingsProvider.notifier).setProfile(next); }),
      SwitchListTile(secondary: const Icon(Icons.vibration), title: Text(t.t('haptics')), value: haptics, onChanged: (v) => ref.read(settingsProvider.notifier).setHaptics(v)),
      ListTile(leading: const Icon(Icons.language), title: const Text('Language'), subtitle: const Text('Tap to toggle KA/EN'), onTap: () { final locale = Localizations.localeOf(context); final next = locale.languageCode == 'ka' ? const Locale('en') : const Locale('ka'); ref.read(settingsProvider.notifier).setLocale(next); }),
      if (!seen) ListTile(leading: const Icon(Icons.info_outline), title: const Text('Price bands'), subtitle: const Text('Low up to 40 GEL. Mid 40 to 80. High 80+.'), onTap: () => ref.read(settingsProvider.notifier).markSeenPriceLegend()),
      const Divider(),
      ListTile(leading: const Icon(Icons.cleaning_services_outlined), title: Text(t.t('clear_cache')), onTap: () async { final sp = await SharedPreferences.getInstance(); await sp.remove('deck'); await sp.remove('shortlist'); await sp.remove('saved'); await sp.remove('history'); Toasts.show(context, t.t('done')); }),
      ListTile(leading: const Icon(Icons.delete_outline), title: Text(t.t('clear_media')), onTap: () async { final dir = await getApplicationDocumentsDirectory(); try { for (final f in dir.listSync()) { try { f.deleteSync(recursive: true); } catch (_) {} } } catch (_) {} Toasts.show(context, t.t('done')); }),
    ]);
  }
}
