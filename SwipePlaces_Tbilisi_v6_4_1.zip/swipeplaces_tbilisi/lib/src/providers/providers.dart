import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/venue.dart';
import '../models/event_item.dart';
import '../models/media_item.dart';
import '../services/remote_config.dart';
import '../services/location_service.dart';
import '../services/places_repository.dart';
import '../services/media_repository.dart';
import '../services/analytics.dart';

final remoteConfigProvider = FutureProvider<RemoteConfig>((ref) async => RemoteConfig.load());
final locationProvider = Provider<LocationService>((ref) => LocationService());
final repoProvider = Provider<PlacesRepository>((ref) => PlacesRepository());
final mediaRepoProvider = Provider<MediaRepository>((ref) => LocalMediaRepository());

final deckProvider = StateNotifierProvider<DeckNotifier, List<Venue>>((ref) => DeckNotifier(ref));
final shortlistProvider = StateNotifierProvider<ShortlistNotifier, List<Venue>>((ref) => ShortlistNotifier());
final savedProvider = StateNotifierProvider<SavedNotifier, List<Venue>>((ref) => SavedNotifier());
final historyProvider = StateNotifierProvider<HistoryNotifier, List<Venue>>((ref) => HistoryNotifier());

final quickChipsProvider = StateProvider<Set<String>>((ref) => <String>{});
final searchQueryProvider = StateProvider<String>((ref) => '');
final districtFilterProvider = StateProvider<String?>((ref) => null);

final eventsProvider = Provider<List<EventItem>>((ref) => [
  EventItem(id: 'e1', title: 'Opening Night', venueId: 'v4', venueName: 'Bassiani', date: '2025-08-15', start: '23:00', end: '06:00', tags: ['techno','dj'], coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=1200'),
  EventItem(id: 'e2', title: 'Live Cocktails', venueId: 'v2', venueName: 'Drama Bar', date: '2025-08-16', start: '20:00', end: '02:00', tags: ['cocktails','live'], coverUrl: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=1200'),
]);

class MediaNotifier extends StateNotifier<List<MediaItem>> {
  final Ref ref;
  final String venueId;
  MediaNotifier(this.ref, this.venueId) : super(const []) { _load(); }
  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString('media_$venueId');
    if (raw == null) return;
    final list = (json.decode(raw) as List).cast<Map<String, dynamic>>().map(MediaItem.fromJson).toList();
    state = list;
    await _pruneMissing();
  }
  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('media_$venueId', json.encode(state.map((e) => e.toJson()).toList()));
  }
  Future<void> _pruneMissing() async {
    final repo = ref.read(mediaRepoProvider);
    final paths = await repo.listLocalPaths();
    state = state.where((m) => paths.contains(m.path)).toList();
    await _save();
  }
  Future<void> add(MediaItem m) async { state = [...state, m]; await _save(); Analytics.log('media_add_${m.type}', {'venueId': venueId}); await _pruneMissing(); }
  Future<void> delete(MediaItem m) async {
    final repo = ref.read(mediaRepoProvider);
    await repo.delete(m);
    state = [...state]..removeWhere((e) => e.id == m.id);
    await _save();
    Analytics.log('media_delete', {'venueId': venueId});
  }
  Future<void> report(MediaItem m, String reason) async {
    final idx = state.indexWhere((e) => e.id == m.id);
    if (idx == -1) return;
    final updated = state[idx].copyWith(reported: true, reportReason: reason);
    final copy = [...state]; copy[idx] = updated; state = copy;
    await _save();
    Analytics.log('media_report', {'venueId': venueId, 'reason': reason});
  }
}
final mediaProvider = StateNotifierProvider.family<MediaNotifier, List<MediaItem>, String>((ref, venueId) => MediaNotifier(ref, venueId));

class DeckNotifier extends StateNotifier<List<Venue>> {
  final Ref ref;
  DeckNotifier(this.ref) : super(const []) { _bootstrap(); }
  Future<void> _bootstrap() async {
    final sp = await SharedPreferences.getInstance();
    final raw = sp.getString('deck');
    if (raw != null) {
      final list = (json.decode(raw) as List).cast<Map<String, dynamic>>().map(Venue.fromJson).toList();
      state = list;
    }
    await refresh();
  }
  Future<void> refresh() async {
    final loc = await ref.read(locationProvider).getPosition();
    final rc = await ref.read(remoteConfigProvider.future);
    final repo = ref.read(repoProvider);
    final list = await repo.fetchDeck(lat: loc.$1, lng: loc.$2, radiusMeters: rc.preloadRadius());
    state = list;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('deck', json.encode(list.map((e) => e.toJson()).toList()));
  }
  void swipeLeft(Venue v) { state = [...state]..removeWhere((e) => e.id == v.id); }
  void markViewed(Venue v) async { final h = ref.read(historyProvider.notifier); await h.add(v); }
}

class ShortlistNotifier extends StateNotifier<List<Venue>> {
  ShortlistNotifier() : super(const []) { _load(); }
  Future<void> _load() async { final sp = await SharedPreferences.getInstance(); final raw = sp.getString('shortlist'); if (raw == null) return; state = (json.decode(raw) as List).cast<Map<String, dynamic>>().map(Venue.fromJson).toList(); }
  Future<void> add(Venue v) async { if (state.any((e) => e.id == v.id)) return; state = [...state, v]; final sp = await SharedPreferences.getInstance(); await sp.setString('shortlist', json.encode(state.map((e) => e.toJson()).toList())); }
  Future<void> remove(Venue v) async { state = [...state]..removeWhere((e) => e.id == v.id); final sp = await SharedPreferences.getInstance(); await sp.setString('shortlist', json.encode(state.map((e) => e.toJson()).toList())); }
}

class SavedNotifier extends StateNotifier<List<Venue>> {
  SavedNotifier() : super(const []) { _load(); }
  Future<void> _load() async { final sp = await SharedPreferences.getInstance(); final raw = sp.getString('saved'); if (raw == null) return; state = (json.decode(raw) as List).cast<Map<String, dynamic>>().map(Venue.fromJson).toList(); }
  Future<void> add(Venue v) async { if (state.any((e) => e.id == v.id)) return; state = [...state, v]; final sp = await SharedPreferences.getInstance(); await sp.setString('saved', json.encode(state.map((e) => e.toJson()).toList())); }
  Future<void> remove(Venue v) async { state = [...state]..removeWhere((e) => e.id == v.id); final sp = await SharedPreferences.getInstance(); await sp.setString('saved', json.encode(state.map((e) => e.toJson()).toList())); }
}

class HistoryNotifier extends StateNotifier<List<Venue>> {
  HistoryNotifier() : super(const []) { _load(); }
  Future<void> _load() async { final sp = await SharedPreferences.getInstance(); final raw = sp.getString('history'); if (raw == null) return; state = (json.decode(raw) as List).cast<Map<String, dynamic>>().map(Venue.fromJson).toList(); }
  Future<void> add(Venue v) async { if (state.any((e) => e.id == v.id)) return; state = [...state, v]; final sp = await SharedPreferences.getInstance(); await sp.setString('history', json.encode(state.map((e) => e.toJson()).toList())); }
}
