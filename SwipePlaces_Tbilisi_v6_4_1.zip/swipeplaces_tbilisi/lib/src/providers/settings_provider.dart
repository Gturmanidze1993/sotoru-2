import 'dart:ui';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsState {
  final Locale locale;
  final String profile;
  final bool seenPriceLegend;
  final bool hapticsEnabled;
  const SettingsState({required this.locale, required this.profile, required this.seenPriceLegend, required this.hapticsEnabled});
  SettingsState copyWith({Locale? locale, String? profile, bool? seenPriceLegend, bool? hapticsEnabled}) =>
      SettingsState(locale: locale ?? this.locale, profile: profile ?? this.profile, seenPriceLegend: seenPriceLegend ?? this.seenPriceLegend, hapticsEnabled: hapticsEnabled ?? this.hapticsEnabled);
}

class SettingsNotifier extends StateNotifier<SettingsState> {
  SettingsNotifier() : super(const SettingsState(locale: Locale('en'), profile: 'local', seenPriceLegend: false, hapticsEnabled: true)) { _load(); }
  Future<void> _load() async {
    final sp = await SharedPreferences.getInstance();
    final code = sp.getString('locale') ?? 'en';
    final profile = sp.getString('profile') ?? 'local';
    final seen = sp.getBool('seen_price_legend') ?? false;
    final haptics = sp.getBool('haptics_enabled') ?? true;
    state = state.copyWith(locale: Locale(code), profile: profile, seenPriceLegend: seen, hapticsEnabled: haptics);
  }
  Future<void> setLocale(Locale l) async { state = state.copyWith(locale: l); final sp = await SharedPreferences.getInstance(); await sp.setString('locale', l.languageCode); }
  Future<void> setProfile(String p) async { state = state.copyWith(profile: p); final sp = await SharedPreferences.getInstance(); await sp.setString('profile', p); }
  Future<void> markSeenPriceLegend() async { state = state.copyWith(seenPriceLegend: true); final sp = await SharedPreferences.getInstance(); await sp.setBool('seen_price_legend', true); }
  Future<void> setHaptics(bool enabled) async { state = state.copyWith(hapticsEnabled: enabled); final sp = await SharedPreferences.getInstance(); await sp.setBool('haptics_enabled', enabled); }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, SettingsState>((ref) => SettingsNotifier());
