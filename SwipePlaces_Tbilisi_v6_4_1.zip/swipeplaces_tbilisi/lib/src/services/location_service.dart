import 'package:geolocator/geolocator.dart';

class LocationService {
  static const _tbilisiCenter = (lat: 41.7151, lng: 44.8271);
  Future<(double, double)> getPosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    LocationPermission permission = await Geolocator.checkPermission();
    if (!serviceEnabled) return (_tbilisiCenter.lat, _tbilisiCenter.lng);
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.deniedForever || permission == LocationPermission.denied) {
      return (_tbilisiCenter.lat, _tbilisiCenter.lng);
    }
    final p = await Geolocator.getCurrentPosition();
    return (p.latitude, p.longitude);
  }
}
