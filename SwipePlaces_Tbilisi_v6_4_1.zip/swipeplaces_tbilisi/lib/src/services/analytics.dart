class Analytics { static void log(String event, [Map<String, dynamic>? params]) {} }
