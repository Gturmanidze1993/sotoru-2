import 'dart:io';
import 'dart:math';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../models/media_item.dart';

abstract class MediaRepository {
  Future<MediaItem> saveImage(String venueId, XFile file);
  Future<MediaItem> saveVideo(String venueId, XFile file, {int maxDurationSeconds = 10});
  Future<void> delete(MediaItem item);
  Future<void> enforceQuota({int maxBytes = 200 * 1024 * 1024});
  Future<List<String>> listLocalPaths();
}

class LocalMediaRepository implements MediaRepository {
  Future<String> _copyToAppDir(XFile file, String prefix) async {
    final dir = await getApplicationDocumentsDirectory();
    final ext = file.path.split('.').last;
    final name = '${prefix}_${DateTime.now().millisecondsSinceEpoch}.$ext';
    final dest = File('${dir.path}/$name');
    await dest.writeAsBytes(await file.readAsBytes(), flush: true);
    return dest.path;
  }

  Future<String> _saveWebPCompressed(XFile file, String prefix) async {
    final dir = await getApplicationDocumentsDirectory();
    final name = '${prefix}_${DateTime.now().millisecondsSinceEpoch}.webp';
    final dest = File('${dir.path}/$name');
    final bytes = await file.readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) {
      await dest.writeAsBytes(bytes, flush: true);
      return dest.path;
    }
    final maxEdge = 1600;
    final w = decoded.width;
    final h = decoded.height;
    img.Image resized = decoded;
    if (max(w, h) > maxEdge) {
      final scale = maxEdge / max(w, h);
      resized = img.copyResize(decoded, width: (w * scale).round(), height: (h * scale).round());
    }
    final webp = img.encodeWebp(resized, quality: 85);
    await dest.writeAsBytes(webp, flush: true);
    return dest.path;
  }

  @override
  Future<MediaItem> saveImage(String venueId, XFile file) async {
    final path = await _saveWebPCompressed(file, 'img_${venueId}');
    final item = MediaItem(
      id: 'm_${DateTime.now().millisecondsSinceEpoch}',
      venueId: venueId,
      type: 'image',
      path: path,
      duration: 0,
      ts: DateTime.now().millisecondsSinceEpoch,
    );
    await enforceQuota();
    return item;
  }

  @override
  Future<MediaItem> saveVideo(String venueId, XFile file, {int maxDurationSeconds = 10}) async {
    final path = await _copyToAppDir(file, 'vid_${venueId}');
    final item = MediaItem(
      id: 'm_${DateTime.now().millisecondsSinceEpoch}',
      venueId: venueId,
      type: 'video',
      path: path,
      duration: maxDurationSeconds,
      ts: DateTime.now().millisecondsSinceEpoch,
    );
    await enforceQuota();
    return item;
  }

  @override
  Future<void> delete(MediaItem item) async {
    try { await File(item.path).delete(); } catch (_) {}
  }

  @override
  Future<void> enforceQuota({int maxBytes = 200 * 1024 * 1024}) async {
    final dir = await getApplicationDocumentsDirectory();
    final files = dir.listSync().whereType<File>().toList();
    files.sort((a, b) => a.lastModifiedSync().millisecondsSinceEpoch.compareTo(b.lastModifiedSync().millisecondsSinceEpoch));
    int total = files.fold(0, (sum, f) => sum + (f.existsSync() ? f.lengthSync() : 0));
    while (total > maxBytes && files.isNotEmpty) {
      final f = files.removeAt(0);
      final size = f.lengthSync();
      try { f.deleteSync(); } catch (_) {}
      total -= size;
    }
  }

  @override
  Future<List<String>> listLocalPaths() async {
    final dir = await getApplicationDocumentsDirectory();
    final files = dir.listSync().whereType<File>().toList();
    return files.map((f) => f.path).toList();
  }
}
