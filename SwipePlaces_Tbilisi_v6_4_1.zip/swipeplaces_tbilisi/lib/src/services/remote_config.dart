import 'dart:convert';
import 'package:flutter/services.dart';

class RemoteConfig {
  final Map<String, dynamic> data;
  RemoteConfig(this.data);

  static Future<RemoteConfig> load() async {
    final raw = await rootBundle.loadString('assets/remote_config.json');
    return RemoteConfig(json.decode(raw) as Map<String, dynamic>);
  }

  double weight(String key) => (data['weights'][key] as num).toDouble();
  int preloadRadius() => data['preloadRadiusMeters'] as int;
  bool flag(String key) => (data['flags'][key] as bool?) ?? false;
  int sponsorFrequency() => (data['sponsor']['frequency_cards'] as num).toInt();
  int sponsorDailyCap() => (data['sponsor']['max_per_day'] as num).toInt();
}
