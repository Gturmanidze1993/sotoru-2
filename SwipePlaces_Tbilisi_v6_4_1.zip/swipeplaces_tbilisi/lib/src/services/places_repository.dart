import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/venue.dart';

class PlacesRepository {
  static const String apiKey = 'YOUR_GOOGLE_PLACES_API_KEY';

  Future<List<Venue>> fetchDeck({required double lat, required double lng, required int radiusMeters}) async {
    final lists = <List<Map<String, dynamic>>>[];
    for (final type in ['bar','restaurant','night_club']) {
      final r = await _nearby(lat, lng, radiusMeters, type);
      lists.add(r);
    }
    final merged = _dedupeByPlaceId(lists.expand((e) => e).toList());
    return merged.map(_toVenue).toList();
  }

  Future<List<Map<String, dynamic>>> _nearby(double lat, double lng, int radius, String type) async {
    final uri = Uri.https('maps.googleapis.com', '/maps/api/place/nearbysearch/json', {
      'key': apiKey, 'location': '$lat,$lng', 'radius': '$radius', 'type': type, 'opennow': 'true',
    });
    http.Response res;
    try {
      res = await http.get(uri).timeout(const Duration(seconds: 6));
    } catch (_) {
      await Future.delayed(const Duration(milliseconds: 500));
      res = await http.get(uri).timeout(const Duration(seconds: 6));
    }
    if (res.statusCode != 200) return [];
    final data = json.decode(res.body) as Map<String, dynamic>;
    final results = (data['results'] as List?)?.cast<Map<String, dynamic>>() ?? const [];
    return results;
  }

  List<Map<String, dynamic>> _dedupeByPlaceId(List<Map<String, dynamic>> list) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final r in list) {
      final id = (r['place_id'] ?? '').toString();
      if (id.isEmpty || seen.contains(id)) continue;
      seen.add(id);
      out.add(r);
    }
    return out;
  }

  Venue _toVenue(Map<String, dynamic> r) {
    final loc = r['geometry']?['location'] ?? {'lat': 41.7151, 'lng': 44.8271};
    final types = (r['types'] as List?)?.cast<String>() ?? const [];
    final isClub = types.contains('night_club');
    final isBar = types.contains('bar');
    final name = (r['name'] ?? '').toString();
    final districts = ['Vake','Vera','Saburtalo','Old Tbilisi','Marjanishvili','Didube'];
    final district = districts[name.hashCode.abs() % districts.length];
    final band = ['low','mid','high'][name.hashCode.abs() % 3];
    final queue = (name.hashCode.abs() % 30);
    final noise = 2 + (name.hashCode.abs() % 4);
    final ratingNum = (r['rating'] is num) ? (r['rating'] as num).toDouble() : 0.0;
    final openNow = r['opening_hours']?['open_now'] == true;

    return Venue(
      id: (r['place_id'] ?? '').toString(),
      name: name,
      type: isClub ? 'club' : (isBar ? 'bar' : 'restaurant'),
      lat: (loc['lat'] as num?)?.toDouble() ?? 41.7151,
      lng: (loc['lng'] as num?)?.toDouble() ?? 44.8271,
      rating: ratingNum,
      priceLevel: (r['price_level'] as int?) ?? 0,
      priceBand: band,
      address: (r['vicinity'] ?? '').toString(),
      photoUrl: _photoUrl(r),
      phone: '',
      website: '',
      tags: types,
      openNow: openNow,
      district: district,
      queueMinutes: queue,
      noise: noise,
    );
  }

  String _photoUrl(Map<String, dynamic> r) {
    final photos = r['photos'] as List?;
    if (photos == null || photos.isEmpty) {
      return 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?w=1200';
    }
    final ref = photos.first['photo_reference'];
    return Uri.https('maps.googleapis.com', '/maps/api/place/photo', {
      'key': apiKey, 'photoreference': ref.toString(), 'maxwidth': '1200',
    }).toString();
  }
}
