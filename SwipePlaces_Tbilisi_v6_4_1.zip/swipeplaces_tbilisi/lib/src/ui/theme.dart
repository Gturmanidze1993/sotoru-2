import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData light() {
    final base = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange, brightness: Brightness.light),
      useMaterial3: true,
    );
    return base.copyWith();
  }
  static ThemeData dark() {
    final base = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange, brightness: Brightness.dark),
      useMaterial3: true,
    );
    return base.copyWith();
  }
}
