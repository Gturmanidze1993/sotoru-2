class Venue {
  final String id;
  final String name;
  final String type;
  final double lat;
  final double lng;
  final double rating;
  final int priceLevel;
  final String priceBand;
  final String address;
  final String photoUrl;
  final String phone;
  final String website;
  final List<String> tags;
  final bool openNow;
  final String district;
  final int queueMinutes;
  final int noise;

  const Venue({
    required this.id,
    required this.name,
    required this.type,
    required this.lat,
    required this.lng,
    required this.rating,
    required this.priceLevel,
    required this.priceBand,
    required this.address,
    required this.photoUrl,
    required this.phone,
    required this.website,
    required this.tags,
    required this.openNow,
    required this.district,
    required this.queueMinutes,
    required this.noise,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type,
    'lat': lat,
    'lng': lng,
    'rating': rating,
    'priceLevel': priceLevel,
    'priceBand': priceBand,
    'address': address,
    'photoUrl': photoUrl,
    'phone': phone,
    'website': website,
    'tags': tags,
    'openNow': openNow,
    'district': district,
    'queueMinutes': queueMinutes,
    'noise': noise,
  };

  factory Venue.fromJson(Map<String, dynamic> j) => Venue(
    id: j['id'] ?? '',
    name: j['name'] ?? '',
    type: j['type'] ?? 'restaurant',
    lat: (j['lat'] as num?)?.toDouble() ?? 41.7151,
    lng: (j['lng'] as num?)?.toDouble() ?? 44.8271,
    rating: (j['rating'] as num?)?.toDouble() ?? 0.0,
    priceLevel: j['priceLevel'] ?? 0,
    priceBand: j['priceBand'] ?? 'mid',
    address: j['address'] ?? '',
    photoUrl: j['photoUrl'] ?? '',
    phone: j['phone'] ?? '',
    website: j['website'] ?? '',
    tags: (j['tags'] as List?)?.cast<String>() ?? const [],
    openNow: j['openNow'] ?? false,
    district: j['district'] ?? 'Unknown',
    queueMinutes: j['queueMinutes'] ?? 0,
    noise: j['noise'] ?? 3,
  );
}
