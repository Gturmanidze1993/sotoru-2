class MediaItem {
  final String id;
  final String venueId;
  final String type;
  final String path;
  final int duration;
  final int ts;
  final bool reported;
  final String reportReason;

  const MediaItem({
    required this.id,
    required this.venueId,
    required this.type,
    required this.path,
    required this.duration,
    required this.ts,
    this.reported = false,
    this.reportReason = '',
  });

  factory MediaItem.fromJson(Map<String, dynamic> j) => MediaItem(
    id: j['id'] ?? '',
    venueId: j['venueId'] ?? '',
    type: j['type'] ?? 'image',
    path: j['path'] ?? '',
    duration: j['duration'] ?? 0,
    ts: j['ts'] ?? 0,
    reported: j['reported'] ?? false,
    reportReason: j['reportReason'] ?? '',
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'venueId': venueId,
    'type': type,
    'path': path,
    'duration': duration,
    'ts': ts,
    'reported': reported,
    'reportReason': reportReason,
  };

  MediaItem copyWith({bool? reported, String? reportReason}) => MediaItem(
    id: id,
    venueId: venueId,
    type: type,
    path: path,
    duration: duration,
    ts: ts,
    reported: reported ?? this.reported,
    reportReason: reportReason ?? this.reportReason,
  );
}
