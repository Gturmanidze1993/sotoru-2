class EventItem {
  final String id;
  final String title;
  final String venueId;
  final String venueName;
  final String date;
  final String start;
  final String end;
  final List<String> tags;
  final String coverUrl;

  const EventItem({
    required this.id,
    required this.title,
    required this.venueId,
    required this.venueName,
    required this.date,
    required this.start,
    required this.end,
    required this.tags,
    required this.coverUrl,
  });

  factory EventItem.fromJson(Map<String, dynamic> j) => EventItem(
    id: j['id'] ?? '',
    title: j['title'] ?? '',
    venueId: j['venueId'] ?? '',
    venueName: j['venueName'] ?? '',
    date: j['date'] ?? '',
    start: j['start'] ?? '',
    end: j['end'] ?? '',
    tags: (j['tags'] as List?)?.cast<String>() ?? const [],
    coverUrl: j['coverUrl'] ?? '',
  );
}
